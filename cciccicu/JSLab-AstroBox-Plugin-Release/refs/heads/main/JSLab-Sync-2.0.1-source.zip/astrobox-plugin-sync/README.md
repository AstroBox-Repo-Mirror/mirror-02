# JSLab AstroBox 同步插件

这是 AstroBox v2 第三方插件，用于管理包名为 `icu.ccicc.jslab` 的 JSLab 手环应用。

## 功能

- 发现已连接设备并显示连接状态；
- 刷新、新建、编辑、重命名、删除、上传和下载手环脚本；
- 使用 UI V3 `TEXTAREA` 编辑多行文本；
- 在脚本编辑页打开“脚本数据”，编辑该脚本保存的 `data` / `config` JSON，支持重新读取、保存及下载 JSON；
- 使用请求 ID、分块确认和 15 秒超时处理大文件与断线；
- 接收手环端文件变化事件并合并刷新请求；
- 同名上传前要求确认覆盖，新建和重命名默认不覆盖；
- 字体更换入口当前显示“即将上线”。

握手只检查同步协议 v2，不依赖已禁用的字体能力。文件名校验与手环现有规则保持兼容：最多 128 个 UTF-16 单元，不含路径或 ASCII 控制字符，允许旧文件名中的连续点号；文件列表继续接受数字字符串大小。与 Android 同步器共用 `test-data/sync-compatibility.json` 验证这些兼容行为。

脚本数据编辑通过可选的 `scriptStorageProtocol: 1` 能力启用，主协议继续使用 v2。旧手环不声明该能力时仍可同步源码，数据入口提示更新手环。数据读取使用固定快照，保存会比较读取时的原始数据；运行中的脚本修改过数据时拒绝覆盖并保留编辑内容，可先下载 JSON 后重新读取。数据草稿绑定原设备，断线或切换设备后保留在当前插件会话中，不会保存到其他设备。关闭插件前请下载需要保留的修改。协议细节见 [脚本数据同步扩展](SCRIPT_STORAGE_PROTOCOL.md)。

## 运行边界

插件是 `wasm32-wasip2` WebAssembly Component，只通过 AstroBox Host API 工作：

- `device`：发现当前设备；
- `thirdpartyapp`：启动 `icu.ccicc.jslab`；
- `register`：注册 Interconnect 接收；
- `interconnect`：发送 JSLab RPC；
- `dialog`：选择文件和保存下载内容；
- `timer`：处理超时；
- `ui-v3`：渲染 AstroBox 界面。

插件不包含 Android 应用、证书、签名或官方 Android 同步器配对逻辑。

## 构建

需要 Rust 和 `wasm32-wasip2`：

```powershell
rustup target add wasm32-wasip2
.\build.ps1
```

脚本在 `dist/` 生成带版本号的 `JSLab-Sync-<版本>.abp`，其中包含 manifest、图标和 WASM Component。
官方源分发仓库与后续更新流程见 [官方源分发说明](MARKET.md)。

## JSLab 统一运行器

全部 `.js` 共用同一运行契约，`.ui.js` 保留为普通文件名。此插件原本按 `.js` 校验/传输，不需要更改 WIT 或 RPC 协议版本。
cloudProxy 原样转发请求 body 与服务器 JSON，包含 runtimeContract；AI 契约验证由快应用与云插件负责，文件同步不受影响。
